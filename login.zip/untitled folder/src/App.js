import React from 'react';
import logo from './logo.svg';
import './App.css';
import Authenticationpage from './page/Authenticationpage' 

function App() {
  return (
    <div className="App">
      <Authenticationpage/>
    </div>
  );
}

export default App;
